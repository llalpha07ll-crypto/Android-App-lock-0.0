# App Lock (Samsung Galaxy A14 5G ke liye)

Ye app Android ka **asli system unlock dialog** (fingerprint / PIN / pattern / password) use karta hai,
isliye lock screen bilkul phone ke apne lock jaisi dikhti hai.

## APK banane ka tarika (Android Studio)
1. Android Studio install karein: https://developer.android.com/studio
2. File -> Open -> ye `AppLock` folder select karein, Gradle sync hone dein.
3. Menu: Build -> Build Bundle(s) / APK(s) -> Build APK(s)
4. APK yahan milega: `app/build/outputs/apk/debug/app-debug.apk`
5. APK ko phone mein bhej kar install karein (Unknown sources allow karna padega).

## Phone par setup (important)
1. App kholein -> "Lock service ON karein" dabayein.
2. Settings -> Accessibility -> Installed apps -> **App Lock** -> ON.
   - Agar option grey ho: Settings -> Apps -> App Lock -> upar right 3 dots -> **Allow restricted settings**, phir dobara try karein (Android 13+ par sideloaded apps ke liye zaroori).
3. Settings -> Apps -> App Lock -> Battery -> **Unrestricted**.
4. Settings -> Battery -> Background usage limits -> Never sleeping apps mein App Lock add karein.
5. App Lock kholkar jin apps ko lock karna hai unka switch ON karein.
6. Agar lock screen pop-up na aaye: Settings -> Apps -> App Lock -> **Display over other apps** ON karein.

## Kaise kaam karta hai
- `AppLockService` (Accessibility) dekhti hai kaunsa app khula hai.
- Locked app khulte hi `LockActivity` aati hai jo `BiometricPrompt` (system dialog) dikhati hai.
- Unlock ke baad wo app tab tak khula rehta hai jab tak aap dusre app par na jayein ya screen band na ho.
- Cancel/back dabane par aap home screen par chale jate hain.
