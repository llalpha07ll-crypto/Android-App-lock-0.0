package com.example.applock

import android.content.Context

/** Stores which apps (package names) are locked. */
object LockPrefs {
    private const val FILE = "applock_prefs"
    private const val KEY_LOCKED = "locked_packages"

    fun getLocked(ctx: Context): Set<String> {
        val stored = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getStringSet(KEY_LOCKED, null)
        return stored?.toSet() ?: emptySet()
    }

    fun setLocked(ctx: Context, pkg: String, locked: Boolean) {
        val set = getLocked(ctx).toMutableSet()
        if (locked) set.add(pkg) else set.remove(pkg)
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_LOCKED, set)
            .apply()
    }
}
