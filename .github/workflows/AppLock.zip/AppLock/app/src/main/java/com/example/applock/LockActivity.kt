package com.example.applock

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

/**
 * Shows the Android system authentication dialog (fingerprint / face / PIN / pattern / password).
 * This is the phone's own lock UI, not a custom copy.
 */
class LockActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PKG = "target_pkg"
        private const val AUTHENTICATORS = BIOMETRIC_WEAK or DEVICE_CREDENTIAL
    }

    private var targetPkg: String = ""
    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLockService.lockShowing = true
        targetPkg = intent.getStringExtra(EXTRA_PKG) ?: ""

        val canAuth = BiometricManager.from(this).canAuthenticate(AUTHENTICATORS)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            // No screen lock set on the phone: nothing to ask for, let the app open
            Toast.makeText(this, R.string.no_lock_toast, Toast.LENGTH_LONG).show()
            unlockAndClose()
            return
        }
        showPrompt()
    }

    private fun showPrompt() {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                unlockAndClose()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                // Cancelled / back pressed / too many attempts: send the user home
                goHome()
            }
        })

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.lock_title))
            .setSubtitle(getString(R.string.lock_subtitle, appLabel()))
            .setAllowedAuthenticators(AUTHENTICATORS)
            .build()

        prompt.authenticate(info)
    }

    private fun appLabel(): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(targetPkg, 0)).toString()
    } catch (e: Exception) {
        targetPkg
    }

    private fun unlockAndClose() {
        if (finished) return
        finished = true
        AppLockService.unlockedPkg = targetPkg
        finish()
    }

    private fun goHome() {
        if (finished) return
        finished = true
        AppLockService.unlockedPkg = null
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(home)
        finish()
    }

    @Deprecated("Back on the lock screen sends the user home")
    override fun onBackPressed() {
        goHome()
    }

    override fun onDestroy() {
        AppLockService.lockShowing = false
        super.onDestroy()
    }
}
