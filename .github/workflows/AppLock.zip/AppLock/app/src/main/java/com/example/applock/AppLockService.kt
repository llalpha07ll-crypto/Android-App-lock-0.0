package com.example.applock

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Watches which app comes to the foreground. When a locked app opens,
 * it launches LockActivity, which shows the Android system unlock dialog.
 */
class AppLockService : AccessibilityService() {

    companion object {
        /** Package that was just unlocked; stays unlocked until the user leaves it or the screen turns off. */
        @Volatile
        var unlockedPkg: String? = null

        /** True while LockActivity is on screen (prevents launching it twice). */
        @Volatile
        var lockShowing: Boolean = false
    }

    private val ignoredPackages = setOf(
        "com.android.systemui",
        "android"
    )

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            unlockedPkg = null
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        // Ignore our own screens, system UI (notification shade, the unlock dialog) and keyboards
        if (pkg == packageName || pkg in ignoredPackages || pkg in imePackages()) return

        if (pkg in LockPrefs.getLocked(this)) {
            if (pkg == unlockedPkg || lockShowing) return
            launchLock(pkg)
        } else {
            // User moved to a different app, so the previous app locks again
            unlockedPkg = null
        }
    }

    private fun launchLock(pkg: String) {
        lockShowing = true
        val intent = Intent(this, LockActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )
            putExtra(LockActivity.EXTRA_PKG, pkg)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            lockShowing = false
        }
    }

    private fun imePackages(): Set<String> {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.map { it.packageName }.toSet()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try {
            unregisterReceiver(screenOffReceiver)
        } catch (e: Exception) {
            // receiver was not registered
        }
        super.onDestroy()
    }
}
