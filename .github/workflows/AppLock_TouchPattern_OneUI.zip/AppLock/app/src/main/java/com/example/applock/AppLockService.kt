package com.example.applock

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Detects foreground app changes. Authentication uses the AppLock credential, with optional biometric verification.
 */
class AppLockService : AccessibilityService() {
    companion object {
        @Volatile var unlockedPkg: String? = null
        @Volatile var unlockedUntil: Long = 0L
        @Volatile var lockShowing: Boolean = false
    }

    private val ignoredPackages = setOf("com.android.systemui", "android")

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            unlockedPkg = null
            unlockedUntil = 0L
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in ignoredPackages || pkg in imePackages()) return

        // Our own package is normally ignored to avoid a lock loop. Only protect its main UI.
        if (pkg == packageName) {
            val isMainScreen = event.className?.toString()?.contains("MainActivity") == true
            if (!isMainScreen || lockShowing) return
        }

        val now = SystemClock.elapsedRealtime()
        val locked = LockPrefs.getLocked(this)
        if (pkg == unlockedPkg) {
            if (unlockedUntil == Long.MAX_VALUE || now < unlockedUntil) return
            unlockedPkg = null
            unlockedUntil = 0L
        } else if (unlockedPkg != null && unlockedUntil == Long.MAX_VALUE) {
            // Start the selected grace period only after the user leaves the unlocked app.
            unlockedUntil = now + LockPrefs.getRelockDelay(this) * 1000L
            if (LockPrefs.getRelockDelay(this) == 0) {
                unlockedPkg = null
                unlockedUntil = 0L
            }
        } else if (unlockedPkg != null && now >= unlockedUntil) {
            unlockedPkg = null
            unlockedUntil = 0L
        }

        if (pkg in locked) {
            if (lockShowing) return
            launchLock(pkg)
        }
    }

    private fun launchLock(pkg: String) {
        lockShowing = true
        val intent = Intent(this, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            putExtra(LockActivity.EXTRA_PKG, pkg)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            lockShowing = false
        }
    }

    private fun imePackages(): Set<String> {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.map { it.packageName }.toSet()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try { unregisterReceiver(screenOffReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
