package com.example.applock

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.EditText
import android.widget.LinearLayout
import android.text.TextWatcher
import android.text.Editable
import android.widget.RadioGroup
import android.widget.RadioButton
import android.app.AlertDialog
import android.widget.CompoundButton
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK

class MainActivity : AppCompatActivity() {
    private data class AppItem(val label: String, val pkg: String, val icon: Drawable)
    private lateinit var statusText: TextView
    private lateinit var appAdapter: AppAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.status)
        findViewById<Button>(R.id.enableButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val delays = resources.getStringArray(R.array.relock_delay_labels)
        val values = resources.getIntArray(R.array.relock_delay_values)
        val spinner = findViewById<Spinner>(R.id.relockDelay)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, delays)
        spinner.setSelection(values.indexOf(LockPrefs.getRelockDelay(this)).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                LockPrefs.setRelockDelay(this@MainActivity, values[position])
            }
        }

        appAdapter = AppAdapter(loadApps())
        findViewById<ListView>(R.id.appList).adapter = appAdapter
        findViewById<Button>(R.id.setupLockButton).setOnClickListener { showCredentialSetup() }
        val bio = findViewById<SwitchCompat>(R.id.biometricSwitch)
        bio.isChecked = LockPrefs.biometricEnabled(this)
        bio.setOnCheckedChangeListener { _, checked ->
            if (checked && !LockPrefs.hasCredential(this)) {
                bio.isChecked = false
                android.widget.Toast.makeText(this, "Set a primary PIN, pattern or password first", android.widget.Toast.LENGTH_LONG).show()
            } else if (checked && androidx.biometric.BiometricManager.from(this).canAuthenticate(androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK) != androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS) {
                bio.isChecked = false
                android.widget.Toast.makeText(this, "No enrolled biometric is available", android.widget.Toast.LENGTH_LONG).show()
            } else LockPrefs.setBiometricEnabled(this, checked)
        }
        val search = findViewById<EditText>(R.id.searchApps)
        search.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int) {}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int) { appAdapter.filter(s?.toString().orEmpty()) }
            override fun afterTextChanged(s:Editable?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        findViewById<TextView>(R.id.credentialStatus).text = if (LockPrefs.hasCredential(this)) "Primary lock: ${LockPrefs.getType(this)}" else "No custom lock configured"
        if (::appAdapter.isInitialized) appAdapter.notifyDataSetChanged()
    }

    private fun showCredentialSetup() {
        val choices = arrayOf("PIN", "Pattern", "Password")
        AlertDialog.Builder(this).setTitle("Choose primary lock")
            .setItems(choices) { _, which ->
                val type = choices[which]
                if (type == "Pattern") {
                    showPatternSetup()
                    return@setItems
                }
                val input = EditText(this).apply {
                    hint = if(type == "PIN") "Enter 4–8 digit PIN" else "Enter password (8+ characters)"
                    inputType = if(type == "PIN") 2 else 1
                }
                val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(48,8,48,0); addView(input) }
                AlertDialog.Builder(this).setTitle("Set $type").setView(box)
                    .setPositiveButton("Continue") { _, _ ->
                        val value=input.text.toString()
                        val valid=if(type == "PIN") value.matches(Regex("[0-9]{4,8}")) else value.length >= 8
                        if(!valid) android.widget.Toast.makeText(this, "Invalid $type. Please try again.", android.widget.Toast.LENGTH_LONG).show()
                        else AlertDialog.Builder(this).setTitle("Confirm $type").setMessage("Save this as your AppLock primary credential?")
                            .setNegativeButton("Cancel",null).setPositiveButton("Save") { _, _ -> LockPrefs.setCredential(this,type,value); findViewById<TextView>(R.id.credentialStatus).text="Primary lock: $type"; android.widget.Toast.makeText(this,"$type saved",android.widget.Toast.LENGTH_SHORT).show() }.show()
                    }.setNegativeButton("Cancel",null).show()
            }.setNegativeButton("Cancel",null).show()
    }

    private fun showPatternSetup() {
        val pattern = PatternView(this)
        val hint = TextView(this).apply { text = "Draw an unlock pattern using at least 4 dots"; textSize = 15f; setPadding(8, 12, 8, 8) }
        val clear = Button(this).apply { text = "Clear"; setOnClickListener { pattern.clearPattern() } }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0); addView(hint); addView(pattern, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (300 * resources.displayMetrics.density).toInt())); addView(clear) }
        val dialog = AlertDialog.Builder(this).setTitle("Draw pattern").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Continue", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val first = pattern.pattern()
                if (!pattern.isValidPattern()) { hint.text = "Connect at least 4 different dots"; return@setOnClickListener }
                dialog.dismiss()
                confirmPatternSetup(first)
            }
        }
        dialog.show()
    }

    private fun confirmPatternSetup(first: String) {
        val pattern = PatternView(this)
        val hint = TextView(this).apply { text = "Draw the same pattern again to confirm"; textSize = 15f; setPadding(8, 12, 8, 8) }
        val clear = Button(this).apply { text = "Clear"; setOnClickListener { pattern.clearPattern() } }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0); addView(hint); addView(pattern, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (300 * resources.displayMetrics.density).toInt())); addView(clear) }
        val dialog = AlertDialog.Builder(this).setTitle("Confirm pattern").setView(box).setNegativeButton("Cancel", null).setPositiveButton("Save", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!pattern.isValidPattern()) { hint.text = "Connect at least 4 different dots"; return@setOnClickListener }
                if (pattern.pattern() != first) { hint.text = "Patterns do not match. Clear and try again."; pattern.clearPattern(); return@setOnClickListener }
                LockPrefs.setCredential(this, "Pattern", first)
                findViewById<TextView>(R.id.credentialStatus).text = "Primary lock: Pattern"
                android.widget.Toast.makeText(this, "Pattern saved", android.widget.Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun updateStatus() {
        statusText.setText(when {
            !LockPrefs.hasCredential(this) -> R.string.status_no_lock
            isServiceEnabled() -> R.string.status_on
            else -> R.string.status_off
        })
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/")
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
            .distinctBy { it.activityInfo.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .toMutableList()

        // Add App Lock itself so the user can enable self-protection.
        if (apps.none { it.pkg == packageName }) {
            val info = pm.getApplicationInfo(packageName, 0)
            apps.add(AppItem(pm.getApplicationLabel(info).toString(), packageName, pm.getApplicationIcon(info)))
        }
        return apps.sortedBy { it.label.lowercase() }
    }

    private inner class AppAdapter(private val allItems: List<AppItem>) : BaseAdapter() {
        private var items: List<AppItem> = allItems
        fun filter(q:String) { items = if(q.isBlank()) allItems else allItems.filter { it.label.contains(q,true) || it.pkg.contains(q,true) }; notifyDataSetChanged() }
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: layoutInflater.inflate(R.layout.item_app, parent, false)
            val item = items[position]
            view.findViewById<ImageView>(R.id.icon).setImageDrawable(item.icon)
            view.findViewById<TextView>(R.id.name).text = item.label
            val toggle = view.findViewById<SwitchCompat>(R.id.lockSwitch)
            toggle.setOnCheckedChangeListener(null)
            toggle.isChecked = item.pkg in LockPrefs.getLocked(this@MainActivity)
            toggle.setOnCheckedChangeListener { _, checked ->
                LockPrefs.setLocked(this@MainActivity, item.pkg, checked)
            }
            view.setOnClickListener { toggle.toggle() }
            return view
        }
    }
}
