package com.example.applock

import android.content.Context
import android.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.security.SecureRandom

object LockPrefs {
 private const val FILE="applock_prefs"; private const val KEY_LOCKED="locked_packages"; private const val KEY_DELAY="relock_delay_seconds"
 private const val KEY_TYPE="primary_type"; private const val KEY_HASH="credential_hash"; private const val KEY_SALT="credential_salt"; private const val KEY_BIO="biometric_enabled"
 fun getLocked(ctx:Context):Set<String> = ctx.getSharedPreferences(FILE,0).getStringSet(KEY_LOCKED,null)?.toSet() ?: emptySet()
 fun setLocked(ctx:Context,pkg:String,locked:Boolean){ val s=getLocked(ctx).toMutableSet(); if(locked)s.add(pkg) else s.remove(pkg); ctx.getSharedPreferences(FILE,0).edit().putStringSet(KEY_LOCKED,s).apply() }
 fun getRelockDelay(ctx:Context)=ctx.getSharedPreferences(FILE,0).getInt(KEY_DELAY,0)
 fun setRelockDelay(ctx:Context,seconds:Int){ctx.getSharedPreferences(FILE,0).edit().putInt(KEY_DELAY,seconds).apply()}
 fun getType(ctx:Context)=ctx.getSharedPreferences(FILE,0).getString(KEY_TYPE,"") ?: ""
 fun hasCredential(ctx:Context)=getType(ctx).isNotBlank() && ctx.getSharedPreferences(FILE,0).contains(KEY_HASH)
 fun setCredential(ctx:Context,type:String,value:String){ val salt=ByteArray(16).also{SecureRandom().nextBytes(it)}; val hash=derive(value,salt); ctx.getSharedPreferences(FILE,0).edit().putString(KEY_TYPE,type).putString(KEY_SALT,Base64.encodeToString(salt,Base64.NO_WRAP)).putString(KEY_HASH,Base64.encodeToString(hash,Base64.NO_WRAP)).apply() }
 fun verify(ctx:Context,value:String):Boolean { val p=ctx.getSharedPreferences(FILE,0); val s=p.getString(KEY_SALT,null)?:return false; val h=p.getString(KEY_HASH,null)?:return false; return java.security.MessageDigest.isEqual(derive(value,Base64.decode(s,Base64.NO_WRAP)),Base64.decode(h,Base64.NO_WRAP)) }
 private fun derive(value:String,salt:ByteArray):ByteArray { val spec=PBEKeySpec(value.toCharArray(),salt,120000,256); return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
 fun biometricEnabled(ctx:Context)=ctx.getSharedPreferences(FILE,0).getBoolean(KEY_BIO,false)
 fun setBiometricEnabled(ctx:Context,v:Boolean){ctx.getSharedPreferences(FILE,0).edit().putBoolean(KEY_BIO,v).apply()}
}
