package com.example.applock

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class LockActivity : AppCompatActivity() {
 companion object { const val EXTRA_PKG="target_pkg" }
 private var targetPkg=""; private var finished=false
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); AppLockService.lockShowing=true; targetPkg=intent.getStringExtra(EXTRA_PKG).orEmpty(); showCustomLock() }
 private fun showCustomLock() {
  if(!LockPrefs.hasCredential(this)) { Toast.makeText(this,"Set an AppLock credential first",Toast.LENGTH_LONG).show(); goHome(); return }
  val type=LockPrefs.getType(this)
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(32,32,32,32); setBackgroundColor(0xFFF5F5F7.toInt()) }
  val title=TextView(this).apply { text="Unlock ${appLabel()}"; textSize=25f; setTextColor(0xFF171717.toInt()); gravity=Gravity.CENTER; setPadding(0,0,0,24) }; root.addView(title)
  if (type == "Pattern") {
   val pattern = PatternView(this)
   root.addView(TextView(this).apply { text = "Draw your pattern"; textSize = 16f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
   root.addView(pattern, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (320 * resources.displayMetrics.density).toInt()))
   val clear = Button(this).apply { text = "Clear"; setOnClickListener { pattern.clearPattern() } }; root.addView(clear)
   val unlock = Button(this).apply { text = "Unlock"; setOnClickListener { if (pattern.isValidPattern() && LockPrefs.verify(this@LockActivity, pattern.pattern())) unlockAndClose() else { pattern.clearPattern(); Toast.makeText(this@LockActivity, "Incorrect pattern", Toast.LENGTH_SHORT).show() } } }; root.addView(unlock)
  } else {
   val input=EditText(this).apply { hint=if(type=="PIN") "Enter AppLock PIN" else "Enter AppLock password"; inputType=if(type=="PIN") 2 else 1; gravity=Gravity.CENTER; isSingleLine=true }
   root.addView(input,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT))
   val unlock=Button(this).apply { text="Unlock"; setOnClickListener { if(LockPrefs.verify(this@LockActivity,input.text.toString())) unlockAndClose() else { input.text.clear(); input.error="Incorrect $type" } } }; root.addView(unlock)
  }
  if(LockPrefs.biometricEnabled(this)) { val bio=Button(this).apply { text="Use fingerprint"; setOnClickListener { showBiometric() } }; root.addView(bio) }
  setContentView(root)
 }
 private fun showBiometric() {
  val manager=BiometricManager.from(this)
  if(manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)!=BiometricManager.BIOMETRIC_SUCCESS) { Toast.makeText(this,"Biometric authentication unavailable",Toast.LENGTH_SHORT).show(); return }
  val prompt=BiometricPrompt(this,ContextCompat.getMainExecutor(this),object:BiometricPrompt.AuthenticationCallback(){
   override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){unlockAndClose()}
   override fun onAuthenticationError(code:Int,msg:CharSequence){ Toast.makeText(this@LockActivity,msg,Toast.LENGTH_SHORT).show() }
  })
  val info=BiometricPrompt.PromptInfo.Builder().setTitle("AppLock biometric").setSubtitle("Verify to unlock ${appLabel()}").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK).setNegativeButtonText("Use primary lock").build()
  prompt.authenticate(info)
 }
 private fun appLabel():String=try{packageManager.getApplicationLabel(packageManager.getApplicationInfo(targetPkg,0)).toString()}catch(_:Exception){targetPkg}
 private fun unlockAndClose(){if(finished)return;finished=true;AppLockService.unlockedPkg=targetPkg;AppLockService.unlockedUntil=Long.MAX_VALUE;finish()}
 private fun goHome(){if(finished)return;finished=true;startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));finish()}
 @Deprecated("Back returns home") override fun onBackPressed(){goHome()}
 override fun onDestroy(){AppLockService.lockShowing=false;super.onDestroy()}
}
