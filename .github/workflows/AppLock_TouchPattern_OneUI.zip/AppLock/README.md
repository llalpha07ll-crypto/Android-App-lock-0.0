# AppLock One UI inspired

## Features in this source revision
- English UI with One UI-inspired rounded cards.
- App list search by visible app name or package name.
- One selected primary credential: PIN, pattern sequence, or password.
- Optional Android biometric prompt (biometric only; no device PIN/pattern/password fallback).
- App selection includes AppLock itself for self-protection.
- Configurable relock delay.
- Credentials are stored as PBKDF2-HMAC-SHA256 hashes with random salts.

## Important implementation note
The current Pattern setup uses an ordered 3x3 cell sequence such as `1-2-5-8` typed into the setup and unlock field; it is not yet a touch-drawn Samsung-style pattern grid. The biometric prompt is provided by Android's BiometricPrompt API and requires an enrolled fingerprint/face supported by the device. It does not use the phone's device-credential fallback.

## Build
Requires Android SDK and internet access on the build runner:

```bash
chmod +x gradlew
./gradlew --no-daemon assembleDebug
```

GitHub Actions workflow: `.github/workflows/build.yml`. Upload the contents of this project folder to the repository root (not this ZIP as a file), then run Actions.

## Accessibility disclosure
The app uses an AccessibilityService to detect which app is in the foreground so it can show the lock screen for apps selected by the user. The user must explicitly enable the service in Android Settings. Do not enable it covertly; explain its purpose clearly before requesting access.
