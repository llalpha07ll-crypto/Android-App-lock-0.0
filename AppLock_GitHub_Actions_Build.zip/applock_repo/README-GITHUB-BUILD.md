# Build AppLock APK on GitHub Actions

## Upload this project to GitHub

1. Extract this ZIP on your phone or computer.
2. Create a new, preferably private, GitHub repository.
3. Upload the **contents** of the extracted folder (including the `.github` folder and `AppLock` folder) to the repository root. Do not upload only this ZIP file: GitHub Actions cannot run a workflow stored inside an unopened ZIP archive.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build AppLock APK** and press **Run workflow**, or let it run after a push.
6. When the run completes successfully, open that run and download the `AppLock-debug-apk` artifact. Extract the downloaded artifact ZIP to get the APK.
7. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

## Important limitations and policy notes

- This workflow builds a **debug APK** for testing. It does not create a Play Store-ready signed release. A release build needs a private signing key and securely configured GitHub Actions secrets.
- A successful build does not certify that Google Play Protect will show no warning, and it does not mean the app has passed Google Play review.
- App Lock needs a mechanism to detect which app is currently open. This project uses Android's `AccessibilityService`. Android runs that service in the background after the user explicitly enables it. If the app is not allowed to run any background service at all, automatic app-lock detection cannot work. This project does not add a separate foreground service or hidden startup mechanism.
- The current project must not be described as Google Play policy-compliant yet. For distribution on Google Play, review the Accessibility API policy and add a clear, separate in-app prominent disclosure plus affirmative consent before sending users to enable Accessibility. Complete the Play Console Accessibility declaration and provide the requested demo video. Do not set `isAccessibilityTool=true` unless the app's primary purpose genuinely supports people with disabilities.
- The app must not prevent users from disabling its Accessibility service or uninstalling it, bypass Android security/privacy controls, or collect/share accessibility data beyond the clearly disclosed app-lock purpose.

Official policy: https://support.google.com/googleplay/android-developer/answer/10964491
