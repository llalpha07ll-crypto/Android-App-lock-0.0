# App Lock — One UI-inspired edition

An Android app-lock project with an English interface and a Samsung One UI-inspired layout.

## Features
- Select installed launcher apps to protect.
- App Lock appears in the list and can protect its own main screen.
- Choose a relock grace period: immediately, 5, 10, 30 seconds, or 1 minute after leaving an unlocked app.
- Uses Android's secure BiometricPrompt for fingerprint/face/device PIN, pattern, or password.

## Important security and platform notes
- Android controls the actual biometric/device-credential dialog. Its appearance cannot be fully replaced by a third-party app.
- App Lock uses an Accessibility Service to detect foreground app changes. Android may show a persistent accessibility indicator or restrict background operation.
- Self-lock protects the App Lock main screen. The Android system settings screens opened from App Lock are not protected.
- If no secure screen lock is configured on the phone, protected apps cannot be safely authenticated and will open with a warning.
- The selected delay is a grace period after leaving an app that was successfully unlocked. Screen-off always clears the unlocked state.
- This project is provided as source code; an APK has not been built or signed here.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The debug APK is normally generated at:
`app/build/outputs/apk/debug/app-debug.apk`

## Setup on your phone
1. Install the APK and open **App Lock**.
2. Tap **Enable lock service**.
3. In Android Settings, open Accessibility > Installed apps > App Lock and enable the service.
4. If Android blocks the service for a sideloaded app, open App info > menu > Allow restricted settings, then enable it again.
5. Set your phone's secure screen lock (PIN, pattern, password or fingerprint).
6. Return to App Lock and turn on the switches for the apps you want to protect, including **App Lock** for self-protection.
7. Choose the relock delay in **Lock settings**.

For reliable background operation, set App Lock battery usage to Unrestricted if your device offers that option.
