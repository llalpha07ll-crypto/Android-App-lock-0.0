package com.example.applock

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

/** Uses Android's secure fingerprint / face / PIN / pattern / password authentication UI. */
class LockActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_PKG = "target_pkg"
        private const val AUTHENTICATORS = BIOMETRIC_WEAK or DEVICE_CREDENTIAL
    }

    private var targetPkg: String = ""
    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLockService.lockShowing = true
        targetPkg = intent.getStringExtra(EXTRA_PKG) ?: ""
        val canAuth = BiometricManager.from(this).canAuthenticate(AUTHENTICATORS)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, R.string.no_lock_toast, Toast.LENGTH_LONG).show()
            unlockAndClose()
            return
        }
        showPrompt()
    }

    private fun showPrompt() {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    unlockAndClose()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    goHome()
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.lock_title))
            .setSubtitle(getString(R.string.lock_subtitle, appLabel()))
            .setAllowedAuthenticators(AUTHENTICATORS)
            .build()
        prompt.authenticate(info)
    }

    private fun appLabel(): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(targetPkg, 0)).toString()
    } catch (_: Exception) { targetPkg }

    private fun unlockAndClose() {
        if (finished) return
        finished = true
        AppLockService.unlockedPkg = targetPkg
        AppLockService.unlockedUntil = Long.MAX_VALUE
        finish()
    }

    private fun goHome() {
        if (finished) return
        finished = true
        AppLockService.unlockedPkg = null
        AppLockService.unlockedUntil = 0L
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    @Deprecated("Back on the lock screen sends the user home")
    override fun onBackPressed() { goHome() }

    override fun onDestroy() {
        AppLockService.lockShowing = false
        super.onDestroy()
    }
}
