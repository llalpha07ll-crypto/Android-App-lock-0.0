package com.example.applock

import android.content.Context

/** Stores app-lock selections and the relock delay. */
object LockPrefs {
    private const val FILE = "applock_prefs"
    private const val KEY_LOCKED = "locked_packages"
    private const val KEY_RELOCK_DELAY = "relock_delay_seconds"

    fun getLocked(ctx: Context): Set<String> {
        val stored = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getStringSet(KEY_LOCKED, null)
        return stored?.toSet() ?: emptySet()
    }

    fun setLocked(ctx: Context, pkg: String, locked: Boolean) {
        val set = getLocked(ctx).toMutableSet()
        if (locked) set.add(pkg) else set.remove(pkg)
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_LOCKED, set).apply()
    }

    fun getRelockDelay(ctx: Context): Int =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt(KEY_RELOCK_DELAY, 0)

    fun setRelockDelay(ctx: Context, seconds: Int) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putInt(KEY_RELOCK_DELAY, seconds).apply()
    }
}
